import math

x1 = float(input("Enter x1: "))
y1 = float(input("Enter y1: "))
x2 = float(input("Enter x2: "))
y2 = float(input("Enter y2: "))

distance = math.sqrt(math.pow(x2-x1, 2) + math.pow(y2-y1, 2))

print(f"The distance between the two points is:{distance:.2}")

# Using the math library simplified my process because it helped me save time, it made my code more organized,and it helped me avoid hidden bugs.
# The math library helped me with the root and power functions.
# It wouldve probably more difficult without sqrt and pow.